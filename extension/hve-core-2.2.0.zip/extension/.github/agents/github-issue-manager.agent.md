---
description: 'Deprecated: replaced by github-backlog-manager.agent.md for GitHub issue and backlog management'
tools: ['execute/getTerminalOutput', 'execute/runInTerminal', 'read', 'edit/createDirectory', 'edit/createFile', 'edit/editFiles', 'search', 'web', 'agent', 'github/*']
---

# GitHub Issue Manager

> [!CAUTION]
> This agent is deprecated. Use [github-backlog-manager.agent.md](github-backlog-manager.agent.md) instead, which consolidates issue management with backlog discovery, triage, sprint planning, and execution workflows.

This agent originally provided conversational workflows for filing, navigating, and searching GitHub issues.
